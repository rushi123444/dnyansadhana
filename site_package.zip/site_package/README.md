# ज्ञानसाधना Website — Setup & Deployment Guide

## 📁 Folder Structure
```
dnyansadhana/
├── index.html              → Main homepage
├── admission.html          → Admission form (with WhatsApp integration)
├── css/
│   └── style.css           → All styles (responsive, animations)
├── js/
│   └── main.js             → All JavaScript (gallery, notices, videos)
├── admin/
│   ├── login.html          → Admin login page (NOT linked from homepage)
│   └── dashboard.html      → Full admin dashboard
├── uploads/
│   ├── images/
│   │   └── logo.png        → ← Place your logo here
│   ├── videos/
│   ├── notices/
│   ├── advertisements/
│   └── gallery/
└── data/                   → (for future PHP/MySQL integration)
```

---

## 🚀 Quick Start (Live Hosting)

1. **Upload all files** to your hosting root (public_html / www)
2. **Place your logo** at: `uploads/images/logo.png`
3. **Access admin panel**: `yoursite.com/admin/login.html`

---

## 🔐 Admin Login Credentials
- **URL**: `yourwebsite.com/admin/login.html`
- **Default Username**: `dnyansadhana`
- **Default Password**: `admin@2024`
- ⚠️ **Change these** in `admin/login.html` before going live!

---

## 🛠️ Admin Panel Features
| Feature | Description |
|---------|-------------|
| 📊 Dashboard | Overview stats + recent admissions |
| 📋 Admissions | View all applications + Download CSV/Excel |
| 🖼️ Gallery | Upload/delete photos |
| 📢 Notices | Publish/delete notices (auto-shown in ticker) |
| 🎬 Videos | Add YouTube links or upload video files |
| 📣 Course Ads | Upload advertisement posters |
| ⚙️ Settings | Export data, manage password |

---

## 📱 WhatsApp Integration
- When student submits admission form → auto-opens WhatsApp with all details
- WhatsApp Number: **9011118455** (change in admission.html if needed)

---

## 📊 Data Storage
- All data stored in **browser localStorage** (no database needed)
- Works on any hosting (shared hosting, cPanel, etc.)
- Download student data anytime as **CSV (Excel-compatible)**

---

## 🔧 Customization

### Change WhatsApp Number:
In `admission.html`, search for `9011118455` and replace with your number.

### Change Admin Password:
In `admin/login.html`, change:
```javascript
const ADMIN_USER = 'dnyansadhana';
const ADMIN_PASS = 'admin@2024';
```

### Add Your Logo:
Place `logo.png` in `uploads/images/` folder.

### Add Images for Gallery:
Login to admin → Gallery → Upload images

---

## 📞 Contact Info (Website)
- **Phone**: 9011118455 / 7498554157  
- **Address**: Near Hanuman Mandir, Shyam Nagar, Nanded
- **WhatsApp**: 9011118455

---

## ✅ SEO Features
- Meta title, description, keywords
- Schema.org EducationalOrganization markup
- Mobile-responsive design
- Semantic HTML5 structure
- Google Maps embedded

---

## 🌐 Browser Support
Chrome, Firefox, Safari, Edge (all modern browsers)
Mobile: iOS Safari, Android Chrome ✅

---

*Built for ज्ञानसाधना Coaching Classes & Abacus Academy, Nanded*
