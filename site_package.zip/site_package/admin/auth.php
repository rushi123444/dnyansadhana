<?php
// ============================================
// DNYANSADHANA - Admin Login Handler
// ============================================
session_start();

// CHANGE THESE CREDENTIALS BEFORE DEPLOYMENT
define('ADMIN_USERNAME', 'dnyansadhana_admin');
define('ADMIN_PASSWORD', '$2y$10$6pXCNBbABrM/7GHIb1e0BOtIuTe9JiHSh4WaIBhQVE9sElQRgqiMi'); // admin@2024

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // Rate limiting (simple)
    $attempts_file = __DIR__ . '/../data/login_attempts.json';
    $attempts = [];
    if (file_exists($attempts_file)) {
        $attempts = json_decode(file_get_contents($attempts_file), true) ?? [];
    }
    $ip = $_SERVER['REMOTE_ADDR'];
    $attempts[$ip] = array_filter($attempts[$ip] ?? [], fn($t) => $t > time() - 900);

    if (count($attempts[$ip] ?? []) >= 5) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Too many attempts. Try after 15 minutes.']);
        exit;
    }

    if ($username === ADMIN_USERNAME && password_verify($password, ADMIN_PASSWORD)) {
        $_SESSION['admin'] = true;
        $_SESSION['admin_user'] = $username;
        $_SESSION['login_time'] = time();
        // Clear attempts
        unset($attempts[$ip]);
        file_put_contents($attempts_file, json_encode($attempts));
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
    } else {
        $attempts[$ip][] = time();
        file_put_contents($attempts_file, json_encode($attempts));
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Invalid credentials']);
    }
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}

header('Location: login.php');
exit;
?>
