<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard | Dnyansadhana</title>
  <meta name="robots" content="noindex, nofollow">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" href="../uploads/logo.png">
  <style>
    body { background: #f0f2f5; font-family: var(--font-main); }
    /* Admin Layout */
    .admin-layout { display: flex; min-height: 100vh; }
    .sidebar {
      width: 260px; background: linear-gradient(180deg, #1a237e 0%, #0d1260 100%);
      padding: 1.5rem 0; position: fixed; top: 0; left: 0; height: 100vh;
      overflow-y: auto; z-index: 100;
    }
    .sidebar-brand { padding: 0 1.5rem 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 1rem; display: flex; align-items: center; gap: 10px; }
    .sidebar-brand img { height: 44px; }
    .sidebar-brand-text { color: white; }
    .sidebar-brand-name { font-family: var(--font-display); font-weight: 700; font-size: 1rem; display: block; }
    .sidebar-brand-sub { font-size: 0.7rem; color: rgba(255,255,255,0.6); }
    .sidebar-nav { padding: 0 0.8rem; }
    .sidebar-nav a {
      display: flex; align-items: center; gap: 10px;
      padding: 11px 14px; border-radius: 10px; color: rgba(255,255,255,0.7);
      font-size: 0.9rem; font-weight: 500; margin-bottom: 3px; transition: var(--transition);
    }
    .sidebar-nav a:hover, .sidebar-nav a.active { background: rgba(255,255,255,0.12); color: white; }
    .sidebar-nav .section-label { font-size: 0.72rem; color: rgba(255,255,255,0.35); text-transform: uppercase; letter-spacing: 1px; padding: 12px 14px 4px; }
    .sidebar-logout { margin: 1.5rem 0.8rem 0; }
    .sidebar-logout a { background: rgba(239,68,68,0.15); color: #fca5a5; display: flex; align-items: center; gap: 10px; padding: 11px 14px; border-radius: 10px; font-size: 0.9rem; transition: var(--transition); }
    .sidebar-logout a:hover { background: rgba(239,68,68,0.3); }

    .admin-main { margin-left: 260px; flex: 1; padding: 0; }
    .admin-topbar {
      background: white; padding: 14px 2rem; display: flex; align-items: center;
      justify-content: space-between; box-shadow: 0 1px 10px rgba(0,0,0,0.06);
      position: sticky; top: 0; z-index: 50;
    }
    .admin-topbar h2 { font-size: 1.2rem; color: var(--secondary); }
    .admin-page { padding: 2rem; display: none; }
    .admin-page.active { display: block; }

    /* Stats Cards */
    .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.2rem; margin-bottom: 2rem; }
    .stat-card { background: white; border-radius: var(--radius); padding: 1.5rem; box-shadow: var(--shadow); border-left: 4px solid var(--primary); }
    .stat-card .s-num { font-family: var(--font-display); font-size: 2rem; font-weight: 800; color: var(--primary); }
    .stat-card .s-label { font-size: 0.85rem; color: var(--text2); margin-top: 4px; }
    .stat-card.blue { border-color: var(--secondary); }
    .stat-card.blue .s-num { color: var(--secondary); }
    .stat-card.green { border-color: #22c55e; }
    .stat-card.green .s-num { color: #22c55e; }
    .stat-card.purple { border-color: #8b5cf6; }
    .stat-card.purple .s-num { color: #8b5cf6; }

    /* Panels */
    .panel { background: white; border-radius: var(--radius-lg); padding: 1.8rem; margin-bottom: 1.5rem; box-shadow: var(--shadow); }
    .panel-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 1px solid #f0f0f0; }
    .panel-header h3 { font-size: 1.05rem; color: var(--secondary); }

    /* Table */
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.88rem; }
    .data-table th { background: #f8f9fa; padding: 10px 12px; text-align: left; font-weight: 600; color: var(--text2); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px; }
    .data-table td { padding: 10px 12px; border-bottom: 1px solid #f5f5f5; color: var(--text); }
    .data-table tr:hover td { background: #fafbfc; }
    .status-badge { padding: 3px 10px; border-radius: 50px; font-size: 0.75rem; font-weight: 600; }
    .status-pending { background: #fef9c3; color: #a16207; }
    .status-confirmed { background: #dcfce7; color: #166534; }
    .status-cancelled { background: #fee2e2; color: #991b1b; }

    /* Upload areas */
    .upload-zone {
      border: 2px dashed #e2e8f0; border-radius: var(--radius); padding: 2rem;
      text-align: center; cursor: pointer; transition: var(--transition);
      background: #fafbfc;
    }
    .upload-zone:hover, .upload-zone.drag { border-color: var(--primary); background: rgba(230,92,0,0.03); }
    .upload-zone input { display: none; }
    .upload-icon { font-size: 2.5rem; margin-bottom: 0.5rem; }
    .upload-zone p { color: var(--text2); font-size: 0.9rem; }
    .upload-zone label { cursor: pointer; }

    /* Gallery grid admin */
    .admin-gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 1rem; margin-top: 1rem; }
    .admin-gallery-item { position: relative; border-radius: 10px; overflow: hidden; aspect-ratio: 4/3; }
    .admin-gallery-item img { width: 100%; height: 100%; object-fit: cover; }
    .admin-gallery-item .del-btn { position: absolute; top: 6px; right: 6px; width: 28px; height: 28px; background: rgba(239,68,68,0.9); color: white; border: none; border-radius: 50%; cursor: pointer; font-size: 0.8rem; display: flex; align-items: center; justify-content: center; }

    /* Video list */
    .video-list-item { display: flex; align-items: center; gap: 1rem; padding: 12px; border: 1px solid #f0f0f0; border-radius: 10px; margin-bottom: 8px; }
    .video-list-item .vi-icon { font-size: 1.8rem; }
    .video-list-item .vi-info { flex: 1; }
    .video-list-item .vi-info h4 { font-size: 0.95rem; margin-bottom: 2px; }
    .video-list-item .vi-info p { font-size: 0.8rem; color: var(--text2); }

    /* Notice list admin */
    .notice-admin-item { display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px; border: 1px solid #f0f0f0; border-radius: 10px; margin-bottom: 8px; }
    .notice-admin-item p { flex: 1; font-size: 0.9rem; }

    .btn-sm { padding: 7px 14px; font-size: 0.82rem; }
    .btn-danger { background: #ef4444; color: white; border: none; border-radius: 8px; padding: 6px 12px; cursor: pointer; font-size: 0.8rem; transition: var(--transition); }
    .btn-danger:hover { background: #dc2626; }
    .btn-success { background: #22c55e; color: white; border: none; border-radius: 8px; padding: 6px 12px; cursor: pointer; font-size: 0.8rem; }

    .search-bar { padding: 9px 14px; border: 1.5px solid #e2e4e8; border-radius: 8px; font-size: 0.9rem; width: 250px; }

    /* Alerts */
    .alert { padding: 12px 16px; border-radius: 10px; margin-bottom: 1rem; font-size: 0.9rem; }
    .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
    .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }

    @media (max-width: 1024px) { .stats-grid { grid-template-columns: 1fr 1fr; } }
    @media (max-width: 768px) {
      .sidebar { width: 0; transform: translateX(-100%); }
      .sidebar.open { width: 260px; transform: translateX(0); }
      .admin-main { margin-left: 0; }
    }
  </style>
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR -->
  <aside class="sidebar" id="adminSidebar">
    <div class="sidebar-brand">
      <img src="../uploads/logo.png" alt="Logo">
      <div class="sidebar-brand-text">
        <span class="sidebar-brand-name">Admin Panel</span>
        <span class="sidebar-brand-sub">Dnyansadhana</span>
      </div>
    </div>
    <nav class="sidebar-nav">
      <div class="section-label">Main</div>
      <a href="#" onclick="showPage('dashboard')" class="active" id="nav-dashboard">📊 Dashboard</a>
      <a href="#" onclick="showPage('admissions')" id="nav-admissions">🎓 Admissions</a>
      <div class="section-label">Manage</div>
      <a href="#" onclick="showPage('notices')" id="nav-notices">📢 Notices</a>
      <a href="#" onclick="showPage('gallery')" id="nav-gallery">🖼️ Gallery</a>
      <a href="#" onclick="showPage('videos')" id="nav-videos">🎬 Videos</a>
      <a href="#" onclick="showPage('posters')" id="nav-posters">📋 Posters</a>
      <div class="section-label">Website</div>
      <a href="../index.html" target="_blank">🌐 View Website</a>
    </nav>
    <div class="sidebar-logout">
      <a href="auth.php?logout=1">🚪 Logout</a>
    </div>
  </aside>

  <!-- MAIN -->
  <main class="admin-main">
    <div class="admin-topbar">
      <h2 id="pageTitle">📊 Dashboard</h2>
      <div style="display:flex;gap:10px;align-items:center;">
        <span style="font-size:0.85rem;color:var(--text2);">Logged in as <strong>Admin</strong></span>
        <a href="../index.html" target="_blank" class="btn btn-sm btn-outline">🌐 View Site</a>
      </div>
    </div>

    <!-- DASHBOARD -->
    <div class="admin-page active" id="page-dashboard">
      <div class="stats-grid">
        <div class="stat-card">
          <div class="s-num" id="totalAdmissions">—</div>
          <div class="s-label">📋 Total Applications</div>
        </div>
        <div class="stat-card blue">
          <div class="s-num" id="pendingAdmissions">—</div>
          <div class="s-label">⏳ Pending</div>
        </div>
        <div class="stat-card green">
          <div class="s-num" id="confirmedAdmissions">—</div>
          <div class="s-label">✅ Confirmed</div>
        </div>
        <div class="stat-card purple">
          <div class="s-num" id="galleryCount">—</div>
          <div class="s-label">🖼️ Gallery Images</div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-header">
          <h3>📋 Recent Applications</h3>
          <div style="display:flex;gap:10px;">
            <button class="btn btn-primary btn-sm" onclick="exportAdmissions()">⬇️ Export Excel (CSV)</button>
          </div>
        </div>
        <div style="overflow-x:auto;">
          <table class="data-table">
            <thead>
              <tr>
                <th>Receipt</th><th>Student</th><th>Parent</th><th>Mobile</th>
                <th>Class</th><th>Course</th><th>Date</th><th>Status</th><th>Action</th>
              </tr>
            </thead>
            <tbody id="recentAdmissionsTable">
              <tr><td colspan="9" style="text-align:center;padding:2rem;color:var(--text2);">Loading...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ADMISSIONS -->
    <div class="admin-page" id="page-admissions">
      <div class="panel">
        <div class="panel-header">
          <h3>🎓 All Admissions</h3>
          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
            <input type="text" class="search-bar" id="admissionSearch" placeholder="🔍 Search by name, mobile...">
            <button class="btn btn-primary btn-sm" onclick="exportAdmissions()">⬇️ Export to Excel</button>
          </div>
        </div>
        <div style="overflow-x:auto;">
          <table class="data-table">
            <thead>
              <tr>
                <th>Receipt</th><th>Student</th><th>Parent</th><th>Mobile</th>
                <th>Class</th><th>Course</th><th>Gender</th><th>School</th>
                <th>Date</th><th>Status</th><th>Action</th>
              </tr>
            </thead>
            <tbody id="fullAdmissionsTable">
              <tr><td colspan="11" style="text-align:center;padding:2rem;color:var(--text2);">Loading...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- NOTICES -->
    <div class="admin-page" id="page-notices">
      <div class="panel">
        <div class="panel-header"><h3>📢 Add Notice</h3></div>
        <div style="display:flex;gap:12px;">
          <input type="text" id="noticeText" placeholder="Enter notice text..." style="flex:1;padding:11px 14px;border:1.5px solid #e2e4e8;border-radius:10px;font-size:0.95rem;">
          <button class="btn btn-primary" onclick="addNotice()">+ Add Notice</button>
        </div>
      </div>
      <div class="panel">
        <div class="panel-header"><h3>📋 Current Notices</h3></div>
        <div id="noticesList"></div>
      </div>
    </div>

    <!-- GALLERY -->
    <div class="admin-page" id="page-gallery">
      <div class="panel">
        <div class="panel-header"><h3>📸 Upload Images</h3></div>
        <div class="upload-zone" id="galleryUploadZone">
          <input type="file" id="galleryInput" accept="image/*" multiple>
          <label for="galleryInput">
            <div class="upload-icon">📷</div>
            <p><strong>Click to upload</strong> or drag & drop images here</p>
            <p style="font-size:0.8rem;margin-top:4px;">Supported: JPG, PNG, GIF, WebP (Max 10MB each)</p>
          </label>
        </div>
        <div id="galleryUploadList" style="margin-top:1rem;"></div>
      </div>
      <div class="panel">
        <div class="panel-header"><h3>🖼️ Gallery Images</h3></div>
        <div id="adminGalleryGrid" class="admin-gallery"></div>
      </div>
    </div>

    <!-- VIDEOS -->
    <div class="admin-page" id="page-videos">
      <div class="panel">
        <div class="panel-header"><h3>🎬 Upload Video</h3></div>
        <div class="form-group"><label>Video Title</label><input type="text" id="videoTitle" placeholder="Enter video title"></div>
        <div class="form-group"><label>Description</label><input type="text" id="videoDesc" placeholder="Brief description"></div>
        <div class="upload-zone">
          <input type="file" id="videoInput" accept="video/*">
          <label for="videoInput">
            <div class="upload-icon">🎥</div>
            <p><strong>Click to select video</strong> (MP4, WebM, MOV — Max 50MB)</p>
          </label>
        </div>
        <button class="btn btn-primary" style="margin-top:1rem;" onclick="uploadVideo()">⬆️ Upload Video</button>
      </div>
      <div class="panel">
        <div class="panel-header"><h3>📹 Uploaded Videos</h3></div>
        <div id="videosList"></div>
      </div>
    </div>

    <!-- POSTERS -->
    <div class="admin-page" id="page-posters">
      <div class="panel">
        <div class="panel-header"><h3>📋 Upload Course Poster / Advertisement</h3></div>
        <div class="form-row" style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1rem;">
          <div class="form-group"><label>Poster Title</label><input type="text" id="posterTitle" placeholder="e.g. New Batch Announcement"></div>
          <div class="form-group"><label>Category</label>
            <select id="posterCategory">
              <option value="general">General</option>
              <option value="admissions">Admissions</option>
              <option value="competitive">Competitive Exams</option>
              <option value="abacus">Abacus</option>
              <option value="results">Results</option>
            </select>
          </div>
        </div>
        <div class="upload-zone">
          <input type="file" id="posterInput" accept="image/*">
          <label for="posterInput">
            <div class="upload-icon">🖼️</div>
            <p><strong>Click to upload poster/advertisement</strong></p>
          </label>
        </div>
        <button class="btn btn-primary" style="margin-top:1rem;" onclick="uploadPoster()">⬆️ Upload Poster</button>
      </div>
      <div class="panel">
        <div class="panel-header"><h3>📂 Uploaded Posters</h3></div>
        <div id="postersList" class="admin-gallery"></div>
      </div>
    </div>

  </main>
</div>

<style>
.toast { position:fixed; bottom:30px; right:30px; background:#1a1a2e; color:white; padding:12px 20px; border-radius:10px; font-size:0.9rem; font-weight:600; opacity:0; transition:all 0.4s; z-index:9999; }
.toast.show { opacity:1; }
.toast-success { background:#22c55e; }
.toast-error { background:#ef4444; }
</style>

<script>
let allAdmissions = [];

// Navigation
function showPage(page) {
  document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  document.getElementById('nav-' + page)?.classList.add('active');
  const titles = { dashboard:'📊 Dashboard', admissions:'🎓 Admissions', notices:'📢 Notices', gallery:'🖼️ Gallery', videos:'🎬 Videos', posters:'📋 Posters' };
  document.getElementById('pageTitle').textContent = titles[page] || page;
  if (page === 'admissions') loadAdmissions(true);
  if (page === 'notices') loadNoticesList();
  if (page === 'gallery') loadAdminGallery();
  if (page === 'videos') loadVideosList();
}

// ADMISSIONS
async function loadAdmissions(full = false) {
  try {
    const res = await fetch('handler.php?action=get_admissions');
    allAdmissions = await res.json();
  } catch {
    const local = localStorage.getItem('dcc_admissions');
    allAdmissions = local ? JSON.parse(local) : [];
  }

  document.getElementById('totalAdmissions').textContent = allAdmissions.length;
  document.getElementById('pendingAdmissions').textContent = allAdmissions.filter(a => a.status === 'Pending' || !a.status).length;
  document.getElementById('confirmedAdmissions').textContent = allAdmissions.filter(a => a.status === 'Confirmed').length;

  const tbody = document.getElementById(full ? 'fullAdmissionsTable' : 'recentAdmissionsTable');
  const cols = full ? 11 : 9;
  if (!allAdmissions.length) {
    tbody.innerHTML = `<tr><td colspan="${cols}" style="text-align:center;padding:2rem;color:var(--text2);">No admission data yet.</td></tr>`;
    return;
  }
  const rows = [...allAdmissions].reverse().slice(0, full ? 999 : 10);
  tbody.innerHTML = rows.map(a => `
    <tr>
      <td><strong>${a.receipt_id || '-'}</strong></td>
      <td>${a.student_name}</td>
      <td>${a.parent_name}</td>
      <td><a href="tel:${a.mobile}">${a.mobile}</a></td>
      <td>${a.standard}</td>
      <td>${a.course}</td>
      ${full ? `<td>${a.gender||'-'}</td><td>${a.school||'-'}</td>` : ''}
      <td>${(a.submitted_at||'').substring(0,10)}</td>
      <td>
        <select onchange="updateStatus('${a.receipt_id}', this.value)" style="border:1px solid #e2e4e8;border-radius:6px;padding:4px 8px;font-size:0.8rem;">
          <option ${!a.status||a.status==='Pending'?'selected':''}>Pending</option>
          <option ${a.status==='Confirmed'?'selected':''}>Confirmed</option>
          <option ${a.status==='Cancelled'?'selected':''}>Cancelled</option>
        </select>
      </td>
      <td><a href="https://wa.me/91${a.mobile}" target="_blank" class="btn btn-sm btn-primary" style="font-size:0.75rem;padding:5px 10px;">💬 WA</a></td>
    </tr>
  `).join('');
}

async function updateStatus(receipt, status) {
  const fd = new FormData();
  fd.append('action', 'update_status');
  fd.append('receipt_id', receipt);
  fd.append('status', status);
  await fetch('handler.php', { method: 'POST', body: fd });
  showToast('Status updated!', 'success');
}

function exportAdmissions() {
  window.location.href = 'handler.php?action=export_admissions';
  // Fallback: local CSV
  if (!allAdmissions.length) { showToast('No data to export', 'error'); return; }
  const headers = ['Receipt ID','Student Name','Parent Name','Mobile','Alt Mobile','Address','Standard','Course','School','DOB','Gender','Submitted At','Status'];
  const csv = [headers.join(','), ...allAdmissions.map(a =>
    [a.receipt_id,a.student_name,a.parent_name,a.mobile,a.alt_mobile||'',`"${a.address||''}"`,a.standard,`"${a.course||''}"`,a.school||'',a.dob,a.gender,a.submitted_at,a.status||'Pending'].join(',')
  )].join('\n');
  const link = document.createElement('a');
  link.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
  link.download = 'admissions_' + new Date().toISOString().slice(0,10) + '.csv';
  link.click();
}

// Admission search
document.addEventListener('DOMContentLoaded', () => {
  loadAdmissions();
  loadGalleryCount();

  const search = document.getElementById('admissionSearch');
  if (search) {
    search.addEventListener('input', () => {
      const q = search.value.toLowerCase();
      document.querySelectorAll('#fullAdmissionsTable tr').forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  }
});

async function loadGalleryCount() {
  try {
    const res = await fetch('../php/get_data.php?type=gallery');
    const data = await res.json();
    document.getElementById('galleryCount').textContent = data.length;
  } catch { document.getElementById('galleryCount').textContent = '0'; }
}

// NOTICES
async function loadNoticesList() {
  const container = document.getElementById('noticesList');
  try {
    const res = await fetch('handler.php?action=get_notices');
    const data = await res.json();
    if (!data.length) { container.innerHTML = '<p style="color:var(--text2)">No notices yet.</p>'; return; }
    container.innerHTML = data.map(n => `
      <div class="notice-admin-item">
        <p>${n.text}<br><small style="color:var(--text2)">${n.date}</small></p>
        <button class="btn-danger" onclick="deleteNotice('${n.id}')">Delete</button>
      </div>
    `).join('');
  } catch { container.innerHTML = '<p>Could not load notices.</p>'; }
}

async function addNotice() {
  const text = document.getElementById('noticeText').value.trim();
  if (!text) { showToast('Enter notice text', 'error'); return; }
  const fd = new FormData();
  fd.append('action', 'add_notice');
  fd.append('notice_text', text);
  try {
    await fetch('handler.php', { method: 'POST', body: fd });
    document.getElementById('noticeText').value = '';
    loadNoticesList();
    showToast('Notice added!', 'success');
  } catch { showToast('Error adding notice', 'error'); }
}

async function deleteNotice(id) {
  if (!confirm('Delete this notice?')) return;
  const fd = new FormData();
  fd.append('action', 'delete_notice');
  fd.append('id', id);
  await fetch('handler.php', { method: 'POST', body: fd });
  loadNoticesList();
  showToast('Notice deleted', 'success');
}

// GALLERY
document.getElementById('galleryInput')?.addEventListener('change', (e) => {
  const files = e.target.files;
  const listEl = document.getElementById('galleryUploadList');
  listEl.innerHTML = '';
  Array.from(files).forEach(file => {
    const fd = new FormData();
    fd.append('action', 'upload_gallery');
    fd.append('image', file);
    const item = document.createElement('div');
    item.textContent = '⏳ Uploading ' + file.name + '...';
    item.style.cssText = 'padding:8px;font-size:0.85rem;color:var(--text2)';
    listEl.appendChild(item);
    fetch('handler.php', { method: 'POST', body: fd })
      .then(r => r.json())
      .then(d => {
        item.textContent = d.success ? '✅ ' + file.name + ' uploaded!' : '❌ Failed: ' + file.name;
        item.style.color = d.success ? '#22c55e' : '#ef4444';
        if (d.success) loadAdminGallery();
      });
  });
});

async function loadAdminGallery() {
  const container = document.getElementById('adminGalleryGrid');
  try {
    const res = await fetch('../php/get_data.php?type=gallery');
    const data = await res.json();
    if (!data.length) { container.innerHTML = '<p style="color:var(--text2)">No images yet.</p>'; return; }
    container.innerHTML = data.map(img => `
      <div class="admin-gallery-item">
        <img src="../uploads/gallery/${img}" alt="${img}" loading="lazy">
        <button class="del-btn" onclick="deleteGallery('${img}')">✕</button>
      </div>
    `).join('');
    document.getElementById('galleryCount').textContent = data.length;
  } catch { container.innerHTML = '<p>Error loading gallery.</p>'; }
}

async function deleteGallery(fname) {
  if (!confirm('Delete this image?')) return;
  const fd = new FormData();
  fd.append('action', 'delete_gallery');
  fd.append('file', fname);
  await fetch('handler.php', { method: 'POST', body: fd });
  loadAdminGallery();
  showToast('Image deleted', 'success');
}

// VIDEOS
async function uploadVideo() {
  const file = document.getElementById('videoInput').files[0];
  const title = document.getElementById('videoTitle').value || 'Class Video';
  const desc = document.getElementById('videoDesc').value;
  if (!file) { showToast('Select a video file', 'error'); return; }
  const fd = new FormData();
  fd.append('action', 'upload_video');
  fd.append('video', file);
  fd.append('title', title);
  fd.append('desc', desc);
  showToast('Uploading video...', 'success');
  try {
    const res = await fetch('handler.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.success) { showToast('Video uploaded!', 'success'); loadVideosList(); }
    else showToast('Upload failed', 'error');
  } catch { showToast('Error uploading', 'error'); }
}

async function loadVideosList() {
  const container = document.getElementById('videosList');
  try {
    const res = await fetch('handler.php?action=get_videos');
    const data = await res.json();
    if (!data.length) { container.innerHTML = '<p style="color:var(--text2)">No videos yet.</p>'; return; }
    container.innerHTML = data.map(v => `
      <div class="video-list-item">
        <div class="vi-icon">🎬</div>
        <div class="vi-info"><h4>${v.title}</h4><p>${v.desc || ''} · ${v.date || ''}</p></div>
        <button class="btn-danger" onclick="deleteVideo('${v.id}')">Delete</button>
      </div>
    `).join('');
  } catch { container.innerHTML = '<p>Error loading videos.</p>'; }
}

async function deleteVideo(id) {
  if (!confirm('Delete this video?')) return;
  const fd = new FormData();
  fd.append('action', 'delete_video');
  fd.append('id', id);
  await fetch('handler.php', { method: 'POST', body: fd });
  loadVideosList();
  showToast('Video deleted', 'success');
}

// POSTERS
async function uploadPoster() {
  const file = document.getElementById('posterInput').files[0];
  if (!file) { showToast('Select a poster image', 'error'); return; }
  const fd = new FormData();
  fd.append('action', 'upload_poster');
  fd.append('poster', file);
  fd.append('title', document.getElementById('posterTitle').value || 'Poster');
  fd.append('category', document.getElementById('posterCategory').value);
  const res = await fetch('handler.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) { showToast('Poster uploaded!', 'success'); loadPosters(); }
  else showToast('Upload failed', 'error');
}

function loadPosters() {
  // Can be expanded to list posters
}

// TOAST
function showToast(msg, type = 'success') {
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add('show'), 100);
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, 3500);
}
</script>
</body>
</html>
