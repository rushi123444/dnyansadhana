<?php
// ============================================
// DNYANSADHANA - Admin Upload & Data Handler
// ============================================
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$action  = $_POST['action'] ?? $_GET['action'] ?? '';
$dataDir = __DIR__ . '/../data/';
$uploadsDir = __DIR__ . '/../uploads/';

function saveJson($file, $data) {
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}
function readJson($file) {
    if (!file_exists($file)) return [];
    return json_decode(file_get_contents($file), true) ?? [];
}
function uploadFile($fieldName, $destDir, $allowedTypes = ['jpg','jpeg','png','gif','webp','mp4','pdf']) {
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] !== 0) return false;
    $file = $_FILES[$fieldName];
    $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedTypes)) return false;
    if ($file['size'] > 50 * 1024 * 1024) return false; // 50MB max
    $newName = uniqid() . '_' . time() . '.' . $ext;
    if (!is_dir($destDir)) mkdir($destDir, 0755, true);
    if (move_uploaded_file($file['tmp_name'], $destDir . $newName)) return $newName;
    return false;
}

switch ($action) {
    // ---- NOTICES ----
    case 'add_notice':
        $text = htmlspecialchars(trim($_POST['notice_text'] ?? ''));
        if (empty($text)) { echo json_encode(['success' => false, 'error' => 'Empty notice']); exit; }
        $notices = readJson($dataDir . 'notices.json');
        $notices[] = ['text' => $text, 'date' => date('d M Y'), 'id' => uniqid()];
        saveJson($dataDir . 'notices.json', $notices);
        echo json_encode(['success' => true]);
        break;
    case 'delete_notice':
        $id = $_POST['id'] ?? '';
        $notices = readJson($dataDir . 'notices.json');
        $notices = array_values(array_filter($notices, fn($n) => $n['id'] !== $id));
        saveJson($dataDir . 'notices.json', $notices);
        echo json_encode(['success' => true]);
        break;

    // ---- GALLERY ----
    case 'upload_gallery':
        $file = uploadFile('image', $uploadsDir . 'gallery/', ['jpg','jpeg','png','gif','webp']);
        if ($file) echo json_encode(['success' => true, 'file' => $file]);
        else echo json_encode(['success' => false, 'error' => 'Upload failed']);
        break;
    case 'delete_gallery':
        $fname = basename($_POST['file'] ?? '');
        $path  = $uploadsDir . 'gallery/' . $fname;
        if (file_exists($path)) { unlink($path); echo json_encode(['success' => true]); }
        else echo json_encode(['success' => false]);
        break;

    // ---- VIDEOS ----
    case 'upload_video':
        $file  = uploadFile('video', $uploadsDir . 'videos/', ['mp4','webm','mov']);
        $title = htmlspecialchars(trim($_POST['title'] ?? 'Class Video'));
        $desc  = htmlspecialchars(trim($_POST['desc'] ?? ''));
        if ($file) {
            $videos = readJson($dataDir . 'videos.json');
            $videos[] = ['file' => $file, 'title' => $title, 'desc' => $desc, 'date' => date('Y-m-d'), 'id' => uniqid()];
            saveJson($dataDir . 'videos.json', $videos);
            echo json_encode(['success' => true]);
        } else echo json_encode(['success' => false, 'error' => 'Upload failed']);
        break;
    case 'delete_video':
        $id = $_POST['id'] ?? '';
        $videos = readJson($dataDir . 'videos.json');
        foreach ($videos as $v) {
            if ($v['id'] === $id && file_exists($uploadsDir . 'videos/' . $v['file'])) {
                unlink($uploadsDir . 'videos/' . $v['file']);
            }
        }
        $videos = array_values(array_filter($videos, fn($v) => $v['id'] !== $id));
        saveJson($dataDir . 'videos.json', $videos);
        echo json_encode(['success' => true]);
        break;

    // ---- POSTERS ----
    case 'upload_poster':
        $file  = uploadFile('poster', $uploadsDir . 'posters/', ['jpg','jpeg','png','webp']);
        $title = htmlspecialchars(trim($_POST['title'] ?? 'Poster'));
        $cat   = htmlspecialchars(trim($_POST['category'] ?? 'general'));
        if ($file) {
            $posters = readJson($dataDir . 'posters.json');
            $posters[] = ['file' => $file, 'title' => $title, 'category' => $cat, 'date' => date('Y-m-d'), 'id' => uniqid()];
            saveJson($dataDir . 'posters.json', $posters);
            echo json_encode(['success' => true, 'file' => $file]);
        } else echo json_encode(['success' => false, 'error' => 'Upload failed']);
        break;

    // ---- EXPORT ADMISSIONS ----
    case 'export_admissions':
        $admissions = readJson($dataDir . 'admissions.json');
        // CSV export
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="admissions_' . date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Receipt ID','Student Name','Parent Name','Mobile','Alt Mobile','Address','Standard','Course','School','DOB','Gender','Submitted At','Status']);
        foreach ($admissions as $a) {
            fputcsv($out, [$a['receipt_id'],$a['student_name'],$a['parent_name'],$a['mobile'],$a['alt_mobile'],$a['address'],$a['standard'],$a['course'],$a['school'],$a['dob'],$a['gender'],$a['submitted_at'],$a['status']]);
        }
        fclose($out);
        exit;

    // ---- GET ADMISSIONS LIST ----
    case 'get_admissions':
        $admissions = readJson($dataDir . 'admissions.json');
        echo json_encode(array_reverse($admissions));
        break;

    // ---- UPDATE STATUS ----
    case 'update_status':
        $receipt = $_POST['receipt_id'] ?? '';
        $status  = htmlspecialchars($_POST['status'] ?? 'Pending');
        $admissions = readJson($dataDir . 'admissions.json');
        foreach ($admissions as &$a) {
            if ($a['receipt_id'] === $receipt) $a['status'] = $status;
        }
        saveJson($dataDir . 'admissions.json', $admissions);
        echo json_encode(['success' => true]);
        break;

    // ---- GET NOTICES ----
    case 'get_notices':
        echo json_encode(array_reverse(readJson($dataDir . 'notices.json')));
        break;

    // ---- GET VIDEOS ----
    case 'get_videos':
        echo json_encode(array_reverse(readJson($dataDir . 'videos.json')));
        break;

    default:
        echo json_encode(['error' => 'Unknown action']);
}
?>
