<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login | Dnyansadhana</title>
  <meta name="robots" content="noindex, nofollow">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" type="image/x-icon" href="../favicon.ico" />
  <link rel="icon" type="image/png" sizes="32x32" href="../favicon-32x32.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="../apple-touch-icon.png" />
  <style>
    body { background: linear-gradient(135deg, #1a237e 0%, #283593 50%, #e65c00 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 1.5rem; font-family: var(--font-main); }
    .login-card {
      background: white; border-radius: var(--radius-lg); padding: 3rem 2.5rem;
      max-width: 420px; width: 100%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      text-align: center; animation: slideUp 0.5s ease;
    }
    @keyframes slideUp { from { opacity:0; transform:translateY(30px); } to { opacity:1; transform:translateY(0); } }
    .login-logo { height: 80px; margin: 0 auto 1rem; }
    .login-card h2 { font-family: var(--font-display); color: var(--secondary); margin-bottom: 0.3rem; }
    .login-card p { color: var(--text2); font-size: 0.88rem; margin-bottom: 2rem; }
    .form-group { margin-bottom: 1.2rem; text-align: left; }
    .form-group label { display: block; font-weight: 600; font-size: 0.85rem; margin-bottom: 6px; color: var(--text); }
    .form-group input {
      width: 100%; padding: 12px 14px; border: 1.5px solid #e2e4e8; border-radius: 10px;
      font-size: 0.97rem; transition: var(--transition);
    }
    .form-group input:focus { outline: none; border-color: var(--secondary); box-shadow: 0 0 0 3px rgba(26,35,126,0.08); }
    .login-btn { width: 100%; padding: 13px; background: linear-gradient(135deg, var(--secondary), var(--primary)); color: white; border: none; border-radius: 10px; font-size: 1rem; font-weight: 700; cursor: pointer; font-family: var(--font-display); transition: var(--transition); }
    .login-btn:hover { opacity: 0.9; transform: translateY(-1px); }
    .error-msg { background: #fef2f2; color: #dc2626; padding: 10px 14px; border-radius: 8px; font-size: 0.88rem; margin-bottom: 1rem; display: none; border: 1px solid #fecaca; }
    .security-note { font-size: 0.78rem; color: #aaa; margin-top: 1.5rem; }
    .back-link { display: inline-block; margin-top: 1rem; color: var(--text2); font-size: 0.82rem; }
    .back-link:hover { color: var(--primary); }
  </style>
</head>
<body>
  <div class="login-card">
    <img src="../uploads/logo.png" alt="Logo" class="login-logo">
    <h2>Admin Panel</h2>
    <p>Dnyansadhana Coaching Classes</p>

    <div id="errorMsg" class="error-msg"></div>

    <form id="loginForm">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" id="username" placeholder="Enter admin username" autocomplete="username" required>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" id="password" placeholder="Enter password" autocomplete="current-password" required>
      </div>
      <button type="submit" class="login-btn" id="loginBtn">🔐 Login to Admin Panel</button>
    </form>

    <p class="security-note">🔒 Secure admin access only. Unauthorized access is prohibited.</p>
    <a href="../index.html" class="back-link">← Back to Website</a>
  </div>

  <script>
  document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('loginBtn');
    const errMsg = document.getElementById('errorMsg');
    btn.textContent = 'Logging in...'; btn.disabled = true;
    errMsg.style.display = 'none';

    const fd = new FormData(e.target);
    try {
      const res = await fetch('auth.php', { method: 'POST', body: fd });
      const data = await res.json();
      if (data.success) {
        btn.textContent = '✅ Success! Redirecting...';
        window.location.href = 'dashboard.php';
      } else {
        errMsg.textContent = '❌ ' + (data.error || 'Invalid credentials. Please try again.');
        errMsg.style.display = 'block';
        btn.textContent = '🔐 Login to Admin Panel'; btn.disabled = false;
      }
    } catch {
      errMsg.textContent = '❌ Connection error. Check server configuration.';
      errMsg.style.display = 'block';
      btn.textContent = '🔐 Login to Admin Panel'; btn.disabled = false;
    }
  });
  </script>
</body>
</html>
