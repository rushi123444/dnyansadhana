// ===== DNYANSADHANA MAIN JS =====

window.addEventListener('load', () => {
  setTimeout(() => {
    const pre = document.getElementById('preloader');
    if (pre) pre.classList.add('hidden');
  }, 1800);
});

const navbar = document.getElementById('navbar');
const scrollTopBtn = document.getElementById('scrollTop');

window.addEventListener('scroll', () => {
  if (navbar) navbar.classList.toggle('scrolled', window.scrollY > 50);
  if (scrollTopBtn) scrollTopBtn.classList.toggle('visible', window.scrollY > 300);
  highlightNavLink();
});

if (scrollTopBtn) scrollTopBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

const navToggle = document.getElementById('navToggle');
const navLinks = document.getElementById('navLinks');
if (navToggle && navLinks) {
  navToggle.addEventListener('click', () => navLinks.classList.toggle('open'));
  navLinks.querySelectorAll('a').forEach(l => l.addEventListener('click', () => navLinks.classList.remove('open')));
}

function highlightNavLink() {
  const sections = document.querySelectorAll('section[id]');
  const links = document.querySelectorAll('.nav-link');
  let current = '';
  sections.forEach(sec => { if (window.scrollY >= sec.offsetTop - 100) current = sec.id; });
  links.forEach(l => {
    l.classList.remove('active');
    if (l.getAttribute('href') === '#' + current) l.classList.add('active');
  });
}

function animateCounters() {
  document.querySelectorAll('.stat-num').forEach(el => {
    const target = parseInt(el.dataset.target);
    if (!target) return;
    let current = 0;
    const inc = target / 60;
    const update = () => {
      current = Math.min(current + inc, target);
      el.textContent = Math.floor(current);
      if (current < target) requestAnimationFrame(update);
    };
    update();
  });
}

const obs = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) { e.target.style.opacity = '1'; e.target.style.transform = 'translateY(0)'; }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.course-card,.feature-card,.faculty-card,.contact-card').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(30px)';
  el.style.transition = 'opacity 0.6s ease, transform 0.6s ease'; obs.observe(el);
});

const heroStats = document.querySelector('.hero-stats');
if (heroStats) {
  const cObs = new IntersectionObserver((e) => { if (e[0].isIntersecting) animateCounters(); }, { threshold: 0.5 });
  cObs.observe(heroStats);
}

let galleryImages = [], currentIndex = 0;

function openLightbox(src, i) {
  const lb = document.getElementById('lightbox'), img = document.getElementById('lightboxImg');
  if (!lb || !img) return;
  lb.style.display = 'flex'; img.src = src; currentIndex = i;
  document.body.style.overflow = 'hidden';
}
function closeLightbox() {
  const lb = document.getElementById('lightbox');
  if (lb) lb.style.display = 'none';
  document.body.style.overflow = '';
}
function navigateLightbox(dir) {
  if (!galleryImages.length) return;
  currentIndex = (currentIndex + dir + galleryImages.length) % galleryImages.length;
  document.getElementById('lightboxImg').src = galleryImages[currentIndex];
}
document.getElementById('lightboxClose')?.addEventListener('click', closeLightbox);
document.getElementById('lightboxPrev')?.addEventListener('click', () => navigateLightbox(-1));
document.getElementById('lightboxNext')?.addEventListener('click', () => navigateLightbox(1));
document.getElementById('lightbox')?.addEventListener('click', e => { if (e.target.id === 'lightbox') closeLightbox(); });
document.addEventListener('keydown', e => {
  if (document.getElementById('lightbox')?.style.display === 'flex') {
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') navigateLightbox(-1);
    if (e.key === 'ArrowRight') navigateLightbox(1);
  }
});

function loadGallery() {
  const grid = document.getElementById('galleryGrid');
  if (!grid) return;
  const images = JSON.parse(localStorage.getItem('dn_gallery') || '[]');
  galleryImages = images.map(i => i.src);
  if (!images.length) { grid.innerHTML = '<div class="gallery-empty-msg">Gallery photos will appear here. Manage from admin panel.</div>'; return; }
  grid.innerHTML = images.map((img, i) => `<div class="gallery-item" onclick="openLightbox('${img.src}',${i})"><img src="${img.src}" alt="${img.title||'Gallery'}" loading="lazy"/></div>`).join('');
}

function loadNotices() {
  const list = document.getElementById('noticesList');
  if (!list) return;
  const notices = JSON.parse(localStorage.getItem('dn_notices') || '[]');
  if (!notices.length) { list.innerHTML = '<div class="notice-empty-msg">📋 No notices at the moment. Check back soon!</div>'; return; }
  list.innerHTML = [...notices].reverse().map(n => `<div class="notice-item"><div class="notice-date">${fmtDate(n.date)}</div><div class="notice-text">${n.text}</div></div>`).join('');
  const ticker = document.getElementById('noticeTicker');
  if (ticker) ticker.textContent = notices.map(n => n.text).join(' | ');
}

function loadVideos() {
  const grid = document.getElementById('videosGrid');
  if (!grid) return;
  const videos = JSON.parse(localStorage.getItem('dn_videos') || '[]');
  if (!videos.length) { grid.innerHTML = '<div class="video-empty-msg">🎬 Video lectures will appear here once added by admin.</div>'; return; }
  grid.innerHTML = videos.map(v => {
    if (v.type === 'youtube') {
      const id = (v.url.match(/(?:youtu\.be\/|watch\?v=|embed\/)([^&\n?#]+)/) || [])[1] || '';
      return `<div class="video-item"><iframe src="https://www.youtube.com/embed/${id}" frameborder="0" allowfullscreen></iframe><div class="video-title">${v.title}</div></div>`;
    }
    return `<div class="video-item"><video controls preload="metadata"><source src="${v.url}"></video><div class="video-title">${v.title}</div></div>`;
  }).join('');
}

function loadCourseAds() {
  const c = document.getElementById('courseAdsContainer');
  if (!c) return;
  const ads = JSON.parse(localStorage.getItem('dn_course_ads') || '[]');
  if (!ads.length) return;
  c.innerHTML = `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.5rem;margin-top:2rem;">${ads.map(a=>`<div style="border-radius:16px;overflow:hidden;box-shadow:0 8px 30px rgba(0,0,0,0.12)"><img src="${a.src}" alt="${a.title}" style="width:100%;display:block;"/></div>`).join('')}</div>`;
}

function fmtDate(d) {
  if (!d) return '';
  return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

window.showToast = function(msg, type='') {
  let t = document.querySelector('.toast');
  if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
  t.textContent = msg; t.className = 'toast show ' + type;
  setTimeout(() => t.className = 'toast', 3000);
};

document.addEventListener('DOMContentLoaded', () => {
  loadGallery(); loadNotices(); loadVideos(); loadCourseAds();
});
