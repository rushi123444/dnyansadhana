<?php
// ============================================
// DNYANSADHANA - Admission Form Handler
// ============================================
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

function sanitize($val) { return htmlspecialchars(trim($val ?? '')); }

$student_name = sanitize($_POST['student_name']);
$parent_name  = sanitize($_POST['parent_name']);
$mobile       = sanitize($_POST['mobile']);
$alt_mobile   = sanitize($_POST['alt_mobile']);
$address      = sanitize($_POST['address']);
$standard     = sanitize($_POST['standard']);
$course       = sanitize($_POST['course']);
$school       = sanitize($_POST['school']);
$dob          = sanitize($_POST['dob']);
$gender       = sanitize($_POST['gender']);

// Validation
$errors = [];
if (empty($student_name)) $errors[] = 'Student name is required';
if (empty($parent_name))  $errors[] = 'Parent name is required';
if (!preg_match('/^[0-9]{10}$/', $mobile)) $errors[] = 'Valid 10-digit mobile number required';
if (empty($address))  $errors[] = 'Address is required';
if (empty($standard)) $errors[] = 'Standard/Class is required';
if (empty($course))   $errors[] = 'Course selection is required';
if (empty($dob))      $errors[] = 'Date of birth is required';
if (empty($gender))   $errors[] = 'Gender is required';

if (!empty($errors)) {
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

$dataDir = __DIR__ . '/../data/';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);

$admissions = [];
$file = $dataDir . 'admissions.json';
if (file_exists($file)) {
    $admissions = json_decode(file_get_contents($file), true) ?? [];
}

$receipt_id = 'DCC' . date('Y') . str_pad(count($admissions) + 1, 4, '0', STR_PAD_LEFT);

$entry = [
    'receipt_id'   => $receipt_id,
    'student_name' => $student_name,
    'parent_name'  => $parent_name,
    'mobile'       => $mobile,
    'alt_mobile'   => $alt_mobile,
    'address'      => $address,
    'standard'     => $standard,
    'course'       => $course,
    'school'       => $school,
    'dob'          => $dob,
    'gender'       => $gender,
    'submitted_at' => date('Y-m-d H:i:s'),
    'status'       => 'Pending'
];

$admissions[] = $entry;
file_put_contents($file, json_encode($admissions, JSON_PRETTY_PRINT));

// WhatsApp message (client-side redirect handled in JS)
$wa_msg = urlencode(
    "🎓 *New Admission - Dnyansadhana*\n" .
    "━━━━━━━━━━━━━━━━\n" .
    "Receipt: {$receipt_id}\n" .
    "Student: {$student_name}\n" .
    "Parent: {$parent_name}\n" .
    "Mobile: {$mobile}\n" .
    "Class: {$standard}\n" .
    "Course: {$course}\n" .
    "School: {$school}\n" .
    "Gender: {$gender}\n" .
    "DOB: {$dob}\n" .
    "Address: {$address}\n" .
    "━━━━━━━━━━━━━━━━\n" .
    "Submitted: " . date('d M Y, h:i A')
);

echo json_encode([
    'success'    => true,
    'receipt_id' => $receipt_id,
    'wa_url'     => "https://wa.me/919011118455?text={$wa_msg}",
    'entry'      => $entry
]);
?>
