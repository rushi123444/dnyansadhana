<?php
// ============================================
// DNYANSADHANA - Contact Form Handler
// ============================================
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$name    = htmlspecialchars(trim($_POST['name'] ?? ''));
$mobile  = htmlspecialchars(trim($_POST['mobile'] ?? ''));
$message = htmlspecialchars(trim($_POST['message'] ?? ''));

if (empty($name) || empty($mobile) || empty($message)) {
    echo json_encode(['success' => false, 'error' => 'All fields required']);
    exit;
}

if (!preg_match('/^[0-9]{10}$/', $mobile)) {
    echo json_encode(['success' => false, 'error' => 'Invalid mobile number']);
    exit;
}

$dataDir = __DIR__ . '/../data/';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);

$contacts = [];
$file = $dataDir . 'contacts.json';
if (file_exists($file)) {
    $contacts = json_decode(file_get_contents($file), true) ?? [];
}

$contacts[] = [
    'name' => $name,
    'mobile' => $mobile,
    'message' => $message,
    'date' => date('Y-m-d H:i:s')
];

file_put_contents($file, json_encode($contacts, JSON_PRETTY_PRINT));

echo json_encode(['success' => true, 'message' => 'Contact saved']);
?>
