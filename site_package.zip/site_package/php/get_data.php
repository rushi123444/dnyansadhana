<?php
// ============================================
// DNYANSADHANA - Data Handler (File-based)
// ============================================
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$type = $_GET['type'] ?? '';
$dataDir = __DIR__ . '/../data/';

function readData($file) {
    if (!file_exists($file)) return [];
    $content = file_get_contents($file);
    return json_decode($content, true) ?? [];
}

switch ($type) {
    case 'notices':
        $notices = readData($dataDir . 'notices.json');
        echo json_encode(array_reverse($notices));
        break;
    case 'gallery':
        $galleryDir = __DIR__ . '/../uploads/gallery/';
        $files = [];
        if (is_dir($galleryDir)) {
            foreach (scandir($galleryDir) as $f) {
                if (in_array(strtolower(pathinfo($f, PATHINFO_EXTENSION)), ['jpg','jpeg','png','gif','webp'])) {
                    $files[] = $f;
                }
            }
        }
        echo json_encode($files);
        break;
    case 'videos':
        $videos = readData($dataDir . 'videos.json');
        echo json_encode($videos);
        break;
    case 'admissions':
        // Admin only - check session
        session_start();
        if (!isset($_SESSION['admin'])) { echo json_encode(['error' => 'Unauthorized']); exit; }
        $admissions = readData($dataDir . 'admissions.json');
        echo json_encode($admissions);
        break;
    default:
        echo json_encode([]);
}
?>
